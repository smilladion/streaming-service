package model;

// Bruges til at tjekke hvilken side brugeren befinder sig på i Display, så noget kode kun køres på den side
public enum PageType {
    HOME, FAVS, SEARCH, SORT, INFO, USER
}
